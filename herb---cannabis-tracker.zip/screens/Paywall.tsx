import React from 'react';
import { Button } from '../components/Button';
import { Check } from 'lucide-react';

const HERB_IMAGE = "/mnt/data/herb-mascot.png";

export const Paywall = ({ onClose }) => {
  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 relative overflow-hidden transition-colors">

      {/* Decorative background elements stay the same */}

      <div className="flex-1 px-6 pt-12 flex flex-col z-10">

        {/* TOP IMAGE */}
        <div className="flex justify-center mb-6 relative">
          <img
            src={HERB_IMAGE}
            alt="Herb"
            className="w-32 h-32 rounded-full object-cover border-4 border-munch-light"
          />

          <div className="absolute -bottom-2 bg-yellow-400 text-xs font-bold px-3 py-1 rounded-full border-2 border-white dark:border-gray-800 text-gray-900">
            PRO
          </div>
        </div>

        <h1 className="text-3xl font-black text-center text-munch-dark dark:text-white mb-2">
          Unlock Full Herb
        </h1>
        <p className="text-center text-munch-med dark:text-gray-400 mb-8">
          Get the most out of your tracking.
        </p>

        {/* Rest of file unchanged */}
        <div className="space-y-4 mb-8">
          {[
            'Unlimited History',
            'Advanced Stats & Charts',
            'Cost Tracking',
            'Cloud Backup'
          ].map((feat, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="p-1 bg-green-100 dark:bg-green-900 rounded-full">
                <Check size={16} className="text-munch-green" />
              </div>
              <span className="font-medium text-gray-700 dark:text-gray-300">{feat}</span>
            </div>
          ))}
        </div>

        <div className="mt-auto space-y-3">
          {/* Yearly & Monthly plans unchanged */}
        </div>
      </div>

      {/* Bottom Button section unchanged */}
      <div className="p-6 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 z-20 transition-colors">
        <Button fullWidth onClick={onClose} className="mb-3 shadow-glow">
          Start 7-Day Free Trial
        </Button>
        <p className="text-xs text-center text-gray-400 dark:text-gray-500">
          Recurring billing. Cancel anytime. <br />
          <span className="underline cursor-pointer">Restore Purchase</s
