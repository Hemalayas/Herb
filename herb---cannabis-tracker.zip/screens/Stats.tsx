import React, { useState, useMemo } from 'react';
import { Session } from '../types';

interface StatsProps {
  sessions: Session[];
  costPerGram: number;
}

const TABS = ['Day', 'Week', 'Month', 'All'];

export const Stats: React.FC<StatsProps> = ({ sessions, costPerGram }) => {
  const [activeTab, setActiveTab] = useState('Week');

  // Process data based on active tab
  const { chartData, summary } = useMemo(() => {
    const now = new Date();
    let filtered: Session[] = [];
    let data: { name: string; count: number; label?: string }[] = [];
    let periodLabel = "Sessions per day";

    // Helper to reset time to start of day
    const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

    if (activeTab === 'Day') {
      periodLabel = "Today's Activity";
      const todayStart = startOfDay(now);
      filtered = sessions.filter(s => new Date(s.timestamp) >= todayStart);
      
      // 4-hour blocks
      const blocks = ['Late', 'Early', 'Morn', 'Aft', 'Eve', 'Night'];
      const counts = [0,0,0,0,0,0]; // 0-4, 4-8, 8-12, 12-16, 16-20, 20-24
      
      filtered.forEach(s => {
        const h = new Date(s.timestamp).getHours();
        const idx = Math.floor(h / 4);
        if (idx >= 0 && idx < 6) counts[idx]++;
      });
      
      data = blocks.map((name, i) => ({ name, count: counts[i] }));

    } else if (activeTab === 'Week') {
      periodLabel = "Last 7 Days";
      const start = new Date();
      start.setDate(start.getDate() - 6);
      start.setHours(0,0,0,0);
      
      filtered = sessions.filter(s => new Date(s.timestamp) >= start);
      
      // Fill last 7 days
      for(let i=0; i<7; i++) {
         const d = new Date(start);
         d.setDate(d.getDate() + i);
         const dayName = d.toLocaleDateString('en-US', { weekday: 'short' }); // Mon, Tue
         
         const dayCount = filtered.filter(s => {
           const sd = new Date(s.timestamp);
           return sd.getDate() === d.getDate() && sd.getMonth() === d.getMonth();
         }).length;
         
         data.push({ name: dayName, count: dayCount });
      }

    } else if (activeTab === 'Month') {
      periodLabel = "This Month";
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      filtered = sessions.filter(s => new Date(s.timestamp) >= startOfMonth);
      
      // Group by Weeks (approx 4-5 weeks)
      const weeks = [0,0,0,0,0];
      filtered.forEach(s => {
         const date = new Date(s.timestamp).getDate();
         const weekIdx = Math.floor((date - 1) / 7);
         if(weeks[weekIdx] !== undefined) weeks[weekIdx]++;
      });
      data = ['W1', 'W2', 'W3', 'W4', 'W5'].map((n, i) => ({ name: n, count: weeks[i] }));

    } else { // All
       periodLabel = "Monthly History";
       // Last 6 months
       for(let i=5; i>=0; i--) {
         const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
         const mName = d.toLocaleDateString('en-US', { month: 'short' });
         const count = sessions.filter(s => {
           const sd = new Date(s.timestamp);
           return sd.getMonth() === d.getMonth() && sd.getFullYear() === d.getFullYear();
         }).length;
         data.push({ name: mName, count });
       }
       filtered = sessions; // Metric uses all for "All" tab
    }

    // --- Metrics Calculations ---
    const totalSessions = filtered.length;
    
    // Calculate Total Spent
    // Logic: If session has a stored cost, use it. 
    // If not (old data), try to parse the amount and multiply by CURRENT costPerGram.
    // Default amount fallback is 0.5g if string parsing fails (e.g. 'Quick').
    const totalSpent = filtered.reduce((acc, curr) => {
      if (curr.cost !== undefined && curr.cost !== 0) {
        return acc + curr.cost;
      } else {
        // Fallback for old data
        let grams = parseFloat(curr.amount);
        if (isNaN(grams)) grams = 0.5; // Assume 0.5g for old 'Quick' logs or invalid strings
        return acc + (grams * costPerGram);
      }
    }, 0);
    
    // Avg per day calculation
    let daysDivisor = 1;
    if (activeTab === 'Day') daysDivisor = 1;
    if (activeTab === 'Week') daysDivisor = 7;
    if (activeTab === 'Month') daysDivisor = new Date().getDate();
    if (activeTab === 'All') daysDivisor = 30 * 6;
    
    const avgPerDay = totalSessions > 0 ? (totalSessions / daysDivisor).toFixed(1) : "0";

    // Busiest Day Calculation
    let maxInDay = 0;
    if (activeTab === 'Day') {
      maxInDay = totalSessions;
    } else {
      const dailyCounts: Record<string, number> = {};
      filtered.forEach(s => {
         const k = new Date(s.timestamp).toDateString();
         dailyCounts[k] = (dailyCounts[k] || 0) + 1;
      });
      const values = Object.values(dailyCounts);
      maxInDay = values.length > 0 ? Math.max(...values) : 0;
    }

    return {
        chartData: data,
        summary: {
            totalSessions,
            totalSpent: totalSpent.toFixed(0),
            avgPerDay,
            maxInDay,
            title: periodLabel
        }
    };
  }, [sessions, activeTab, costPerGram]);

  // Determine scale for the chart
  const maxChartValue = Math.max(...chartData.map(d => d.count), 1);

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 p-6 pt-8 overflow-y-auto transition-colors">
      <h1 className="text-2xl font-black text-munch-dark dark:text-white mb-6">Insights</h1>

      {/* Time Filter Tabs */}
      <div className="bg-gray-200 dark:bg-gray-800 p-1 rounded-xl flex mb-8 transition-colors">
        {TABS.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === tab 
                ? 'bg-white dark:bg-gray-700 text-munch-dark dark:text-white shadow-sm scale-105' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Custom Bar Chart Card */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm mb-6 transition-colors min-h-[280px] flex flex-col">
        <div className="flex justify-between items-end mb-6">
          <div>
            <p className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Activity</p>
            <h3 className="text-lg font-bold text-munch-dark dark:text-white">{summary.title}</h3>
          </div>
          <div className="text-2xl font-black text-munch-green">{summary.totalSessions}</div>
        </div>
        
        {/* Chart Area */}
        <div className="flex-1 flex items-end gap-2 w-full h-40 mt-2">
          {chartData.map((item, index) => {
            const heightPct = (item.count / maxChartValue) * 100;
            return (
              <div key={index} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                
                {/* Tooltip Bubble */}
                <div className="absolute -top-8 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-munch-dark dark:bg-gray-700 text-white text-xs font-bold px-2 py-1 rounded pointer-events-none z-10 mb-1 whitespace-nowrap">
                  {item.count} sessions
                </div>

                {/* The Bar Container */}
                <div className="w-full max-w-[18px] sm:max-w-[32px] h-full flex items-end bg-gray-100 dark:bg-gray-700/30 rounded-t-lg overflow-hidden">
                   {/* The Filled Bar */}
                   <div 
                     style={{ height: `${heightPct}%` }}
                     className={`w-full rounded-t-lg transition-all duration-700 ease-out ${
                        item.count > 0 ? 'bg-munch-green group-hover:bg-green-400' : 'bg-transparent'
                     }`}
                   />
                </div>

                {/* X Axis Label */}
                <div className="mt-3 text-[10px] font-bold text-gray-400 dark:text-gray-500 truncate w-full text-center">
                  {item.name}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-20">
        <div className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm transition-colors">
          <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-3 text-blue-500">
            📊
          </div>
          <div className="text-2xl font-black text-munch-dark dark:text-white">{summary.totalSessions}</div>
          <div className="text-xs font-bold text-gray-400 dark:text-gray-500">Total Sessions</div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm transition-colors">
           <div className="w-10 h-10 bg-orange-50 dark:bg-orange-900/30 rounded-full flex items-center justify-center mb-3 text-orange-500">
            🔥
          </div>
          <div className="text-2xl font-black text-munch-dark dark:text-white">{summary.avgPerDay}</div>
          <div className="text-xs font-bold text-gray-400 dark:text-gray-500">Avg. / Day</div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm transition-colors">
          <div className="w-10 h-10 bg-purple-50 dark:bg-purple-900/30 rounded-full flex items-center justify-center mb-3 text-purple-500">
            📅
          </div>
          <div className="text-2xl font-black text-munch-dark dark:text-white">{summary.maxInDay}</div>
          <div className="text-xs font-bold text-gray-400 dark:text-gray-500">Busiest Day</div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm transition-colors">
          <div className="w-10 h-10 bg-green-50 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-3 text-green-500">
            💰
          </div>
          <div className="text-2xl font-black text-munch-dark dark:text-white">${summary.totalSpent}</div>
          <div className="text-xs font-bold text-gray-400 dark:text-gray-500">Est. Cost</div>
        </div>
      </div>
    </div>
  );
};