import React, { useState, useEffect } from 'react';
import { Session } from '../types';
import { LogModal } from '../components/LogModal';
import { Flame, Clock, RotateCcw } from 'lucide-react';
import { Mascot } from '../components/Mascot';

interface HomeProps {
  sessions: Session[];
  onLogSession: (session: Partial<Session>) => void;
  onUndo: () => void;
  dailyGoal: number;
  costPerGram: number;
}

// UPDATED: Clean minimalist cannabis leaf that matches your image
const CannabisLeaf = ({ size = 48, className = "" }: { size?: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {/* Center stem */}
    <path d="M12 20V12" />
    
    {/* Center top leaf */}
    <path d="M12 3C12 3 13 6 13 8C13 10 12 12 12 12C12 12 11 10 11 8C11 6 12 3 12 3Z" />
    
    {/* Left leaves */}
    <path d="M12 12C12 12 9 10 7 9C5 8 3 7 3 7C3 7 5 9 6 10C7 11 12 12 12 12Z" />
    <path d="M12 12C12 12 10 14 9 15C8 16 6 18 6 18C6 18 8 16 9 15C10 14 12 12 12 12Z" />
    
    {/* Right leaves */}
    <path d="M12 12C12 12 15 10 17 9C19 8 21 7 21 7C21 7 19 9 18 10C17 11 12 12 12 12Z" />
    <path d="M12 12C12 14 14 15 15 15C16 16 18 18 18 18C18 18 16 16 15 15C14 14 12 12 12 12Z" />
    
    {/* Bottom outer leaves */}
    <path d="M12 12C12 12 8 13 6 14C4 15 2 17 2 17C2 17 4 15 6 14C8 13 12 12 12 12Z" />
    <path d="M12 12C12 12 16 13 18 14C20 15 22 17 22 17C22 17 20 15 18 14C16 13 12 12 12 12Z" />
  </svg>
);

export const Home: React.FC<HomeProps> = ({ sessions, onLogSession, onUndo, dailyGoal, costPerGram }) => {
  const [isModalOpen, setModalOpen] = useState(false);
  const [todayCount, setTodayCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lastSessionTime, setLastSessionTime] = useState<string | null>(null);

  // Update stats when sessions change
  useEffect(() => {
    const now = new Date();
    const todayString = now.toDateString();
    
    // Today Count
    const todaySessions = sessions.filter(s => new Date(s.timestamp).toDateString() === todayString);
    setTodayCount(todaySessions.length);

    // Last Session Time
    if (todaySessions.length > 0) {
      const last = new Date(todaySessions[0].timestamp);
      const diffMins = Math.floor((now.getTime() - last.getTime()) / 60000);
      if (diffMins < 60) setLastSessionTime(`${diffMins}m ago`);
      else setLastSessionTime(`${Math.floor(diffMins/60)}h ago`);
    } else if (sessions.length > 0) {
      setLastSessionTime("Yesterday");
    } else {
      setLastSessionTime(null);
    }

    // Simple Streak Calc (placeholder)
    if (sessions.length > 0) {
      setStreak(todaySessions.length > 0 ? 5 : 4); 
    }
  }, [sessions]);

  const getMascotMessage = () => {
    if (todayCount === 0) return "Ready to track with Herb?";
    if (todayCount < dailyGoal) return "You're staying balanced!";
    if (todayCount === dailyGoal) return "Maybe take a breather?";
    return "Dude, I'm about to green out.";
  };

  // Quick Log Handler
  const handleQuickLog = () => {
    // Default quick log to 0.5g (avg bowl size)
    const amountStr = '0.5g';
    const cost = 0.5 * costPerGram;
    
    onLogSession({ 
      method: 'Joint', 
      amount: amountStr, 
      strain: 'Quick Log', 
      cost: cost 
    });
  };

  // Progress ring calc
  const progress = Math.min((todayCount / dailyGoal) * 100, 100);
  const radius = 100;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 relative transition-colors">
      {/* Header */}
      <div className="flex justify-between items-center p-6 pt-8">
        <div>
          <h2 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
          </h2>
          <h1 className="text-2xl font-black text-munch-dark dark:text-white">Hello, Friend</h1>
        </div>
        <div className="flex gap-2">
          {lastSessionTime && (
            <div className="bg-gray-100 dark:bg-gray-800 px-3 py-1.5 rounded-full flex items-center gap-1 border border-gray-200 dark:border-gray-700">
              <Clock size={14} className="text-gray-500 dark:text-gray-400" />
              <span className="font-bold text-gray-600 dark:text-gray-300 text-xs">{lastSessionTime}</span>
            </div>
          )}
          <div className="bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-full flex items-center gap-1 border border-orange-100 dark:border-orange-900/30">
            <Flame size={16} className="text-orange-500 fill-orange-500" />
            <span className="font-bold text-orange-600 dark:text-orange-400 text-sm">{streak}</span>
          </div>
        </div>
      </div>

      {/* Main Interaction Area - fixed alignment */}
      <div className="flex-1 flex flex-col items-center justify-center relative px-4">
        <div className="relative grid place-items-center" style={{ width: '288px', height: '288px' }}>
          
          {/* Progress Ring */}
          <svg 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transform -rotate-90" 
            width="256" 
            height="256"
            style={{ pointerEvents: 'none' }}
          >
            <circle
              cx="128"
              cy="128"
              r={radius}
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              className="text-gray-100 dark:text-gray-800"
            />
            <circle
              cx="128"
              cy="128"
              r={radius}
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="text-munch-green transition-all duration-1000 ease-out"
            />
          </svg>

          {/* Pulse Effect */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-green-50 dark:bg-green-900/20 animate-pulse" 
            style={{ width: '208px', height: '208px' }}
          />

          {/* Glow Layer (separate to prevent clipping) */}
           <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full shadow-glow" 
            style={{ width: '176px', height: '176px', zIndex: 10 }}
          />

          {/* Log Button */}
          <button
            onClick={handleQuickLog}
            onContextMenu={(e) => {
              e.preventDefault();
              setModalOpen(true);
            }}
            style={{
              width: '176px',
              height: '176px',
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-munch-green active:scale-95 transition-transform flex flex-col items-center justify-center text-white group border-4 border-white dark:border-gray-900 z-20"
          >
            <CannabisLeaf size={72} className="mb-1" />
            <span className="font-bold text-lg mt-1">Log</span>
            <span className="text-[10px] opacity-80 font-medium absolute bottom-6">Hold for details</span>
          </button>
        </div>

        {/* Undo Button */}
        {todayCount > 0 && (
          <button 
            onClick={onUndo}
            className="mt-2 mb-4 p-2 rounded-full bg-gray-50 dark:bg-gray-800 text-gray-400 dark:text-gray-500 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all flex items-center gap-1.5 text-xs font-bold animate-fade-in"
          >
            <RotateCcw size={14} />
            <span>Undo</span>
          </button>
        )}

        {/* Stats below button */}
        <div className={`${todayCount > 0 ? 'mt-0' : 'mt-8'} text-center transition-all`}>
          <h3 className="text-4xl font-black text-munch-dark dark:text-white">{todayCount}</h3>
          <p className="text-munch-med dark:text-gray-400 font-medium text-sm">Sessions Today</p>
          <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">Goal: {dailyGoal}</p>
        </div>
      </div>

      {/* Footer Herb area, using shared Mascot component */}
      <div className="p-6 pb-8 flex flex-col items-center gap-3">
        <p className="text-munch-med dark:text-gray-400 font-medium text-sm text-center">
          {getMascotMessage()}
        </p>
        <Mascot size="sm" />
      </div>

      <LogModal 
        isOpen={isModalOpen} 
        onClose={() => setModalOpen(false)} 
        onSave={onLogSession}
        costPerGram={costPerGram} 
      />
    </div>
  );
};